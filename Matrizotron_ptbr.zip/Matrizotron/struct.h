#ifndef STRUCT_H
#define STRUCT_H

//DEFININDO OS STRUCTS

typedef struct lista_matrizes
{
    long int m; //LINHA
    long int n; //COLUNA
    char nome[60]; //NOME DA MATRIZ
    struct matriz *head_matriz;
    struct lista_matrizes* aponta_matriz; //Armazena a próxima matriz.
} aponta_matriz;

typedef struct matriz
{
    long int i; //COORDERNADA LINHA
    long int j; //COORDENADA COLUNA
    float valor; //VALOR
    struct matriz* prox;
} elemento_matriz;

#endif