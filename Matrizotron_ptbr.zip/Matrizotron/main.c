#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <windows.h>
#include "struct.h"
#include "funcoes.h"

int main(void)
{
    MATRIZ head_lista;
    lista_matrizes(&head_lista);

    //VARIAVEIS
    int modo_escolhido;

    //WELCOME
    printf("##  BEM VINDO AO MATRIZOTRON  ##\n");
    Sleep(1000);
    printf("        LEIA O README");
    Sleep(800);
    system("cls");

    //MENU
    while (1)
    {
        system("cls");
        printf("### MENU ###\n");
        printf("1 - CRIAR MATRIZ\n");
        printf("2 - EDITAR ELEMENTO DE UMA MATRIZ\n");
        printf("3 - CONSULTAR ELEMENTO DE UMA MATRIZ\n");
        printf("4 - SOMAR LINHA/COLUNA DE UMA MATRIZ\n");
        printf("5 - EXCLUIR MATRIZ\n");
        printf("6 - LISTAR MATRIZES CADASTRADAS\n");
        printf("7 - LISTAR ELEMENTOS NAO NULOS DE UMA MATRIZ\n");
        printf("8 - ZERA TODOS ELEMENTOS DE UMA MATRIZ\n");
        printf("DIGITE 0 PARA SAIR DO PROGRAMA\n\n");
        while (1) //LOOP DE LEITURA DO MODO
        {
            printf("ESCOLHA O MODO: ");
            fflush(stdin);
            scanf("%d", &modo_escolhido);
            if (modo_escolhido <= 8 && modo_escolhido >= 1)
            {
                break; //SAI DO LOOP
            }
            else if (modo_escolhido == 0)
            {
                printf("\nOBRIGADO POR USAR O MATRIZOTRON");
                Sleep(1500);
                return 0; //TERMINA A EXECUCAO
            }
            else
            {
                printf("MODO INVALIDO!");
                Sleep(1500);
            }
        } // FIM DO LOOP DE LEITURA DO MODO


        if (modo_escolhido == 1) //CRIAR MATRIZ  //sf
        {
            char nome_matriz[60];
            int flag = 1, flag2 = 1;
            long int m = 0, n = 0; //TAMANHO DA MATRIZ
            while (flag)
            {
                printf("DIGITE O NOME DA MATRIZ: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz);  //sf
                if (flag)
                {
                    printf("MATRIZ JA CADASTRADA!\n");
                }
            }
            while (flag2)
            {
                printf("DIGITE O NUMERO DE LINHAS: ");
                fflush(stdin);
                scanf("%ld", &m);
                printf("DIGITE O NUMERO DE COLUNAS: ");
                fflush(stdin);
                scanf("%ld", &n);
                if ((m <= 0) || (n <= 0))
                {
                    printf("TAMANHO INVALIDO!\n");
                }
                else
                {
                    flag2 = 0;
                }
            }
            head_lista = criar_matriz(nome_matriz, m, n, &head_lista);
            printf("\n>>Matriz criada com sucesso!\n\n");
            system("pause");
        }


        if (modo_escolhido == 2) //EDITAR ELEMENTO DE UMA MATRIZ
        {
            char nome_matriz[60];
            int flag = 0, flag2 = 1;
            long int i = 0, j = 0; //COORDENADAS DO ELEMENTO
            float valor;
            while (!flag)
            {
                printf("DIGITE O NOME DA MATRIZ: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz);
                if (!flag)
                {
                    printf("MATRIZ NAO CADASTRADA!\n");
                }
            }
            while (flag2)
            {
                printf("DIGITE A LINHA DO ELEMENTO: ");
                fflush(stdin);
                scanf("%ld", &i);
                printf("DIGITE A COLUNA DO ELEMENTO: ");
                fflush(stdin);
                scanf("%ld", &j);
                printf("DIGITE O VALOR DO ELEMENTO:");
                fflush(stdin);
                scanf("%f", &valor);
                if (i <= 0 || j <= 0)
                {
                    printf("COORDENADAS INVALIDAS!\n");
                }
                else
                {
                    flag2 = 0;
                }
            }
            //VERIFICA SE A MATRIZ TEM ESSA LINHA E COLUNA
            MATRIZ atual;
            atual = head_lista;
            while(1) //SE CHEGOU AQUI, O NOME EXISTE, ENTAO SEMPRE EXECUTARA O BREAK
            {
                if(strcmp(nome_matriz, atual->nome) == 0)
                {
                    break;
                }
              atual = atual->aponta_matriz;
            }
            if(i > atual->m || j > atual->n)  //VERIFICA SE AS POSIOES EXISTEM NA MATRIZ
            {
                printf("POSICOES INVALIDAS!\n");
                system("PAUSE");
                continue; //RETORNA PRO MENU
            }
            //VERIFICA O VALOR ATUAL DO ELEMENTO
            float valor_atual;
            valor_atual = consulta_elemento(busca_matriz(head_lista, nome_matriz), i, j);
            if(valor_atual == 0) //SE O VALOR ATUAL DO ELEMENTO FOR ZERO
            {
                criar_elemento(head_lista, nome_matriz, i,j,valor);
                printf("ELEMENTO EDITADO COM SUCESSO!\n");
                system("PAUSE");
                continue;
            }
            else   //SE O VALOR ATUAL DO ELEMENTO NAO FOR 0
            {
                if(valor == 0)
                {
                    deletar_elemento(busca_matriz(head_lista, nome_matriz),i,j);
                    printf("ELEMENTO EDITADO COM SUCESSO!\n");
                    system("PAUSE");
                    continue;
                }
                else
                {
                    editar_elemento(busca_matriz(head_lista,nome_matriz), i, j, valor); //k!
                    printf("ELEMENTO EDITADO COM SUCESSO!\n");
                    system("PAUSE");
                    continue;
                }
            }
            printf("ERRO AO EDITAR ELEMENTO!\n");
            system("PAUSE");
        }


        if (modo_escolhido == 3) //CONSULTAR ELEMENTO DE UMA MATRIZ
        {
            char nome_matriz[60];
            int flag = 0, flag2 = 1;
            long int i = 0, j = 0; //COORDENADAS DO ELEMENTO
            float valor_buscado = 0;
            while (!flag)
            {
                printf("DIGITE O NOME DA MATRIZ: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz);
                if (!flag)
                {
                    printf("MATRIZ NAO CADASTRADA!\n");
                }
            }
            while (flag2)
            {
                printf("DIGITE A LINHA DO ELEMENTO: ");
                fflush(stdin);
                scanf("%ld", &i);
                printf("DIGITE A COLUNA DO ELEMENTO: ");
                fflush(stdin);
                scanf("%ld", &j);
                if (i <= 0 || j <= 0)
                {
                    printf("COORDENADAS INVALIDAS!\n");
                }
                else
                {
                    flag2 = 0;
                }
            }
            valor_buscado = consulta_elemento(busca_matriz(head_lista, nome_matriz),i,j);
            printf("VALOR: %f", valor_buscado);
            system("pause");
        }


        if (modo_escolhido == 4) //SOMAR LINHA/COLUNA DE UMA MATRIZ
        {
            char nome_matriz[60];
            char leitura;
            long int linha_coluna; //LINHA OU COLUNA A SER SOMADA
            int flag = 0, flag2 = 1;
            int flag3 = 1;
            while (!flag)
            {
                printf("DIGITE O NOME DA MATRIZ: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz);
                if (!flag)
                {
                    printf("MATRIZ NAO CADASTRADA!\n");
                }
            }
            while (flag2) //LOOP PARA LER SE QUER SOMAR LINHA OU COLUNA
            {
                printf("DESEJA SOMAR LINHA OU COLUNA (L/C)? ");
                fflush(stdin);
                scanf("%c", &leitura);
                if (leitura == 'l' || leitura == 'L' || leitura == 'c' || leitura == 'C')
                {
                    flag2 = 0;
                }
                else
                {
                    printf("ENTRADA INVALIDA!\n");
                }
            }
            while (flag3)
            {
                if (leitura == 'l' || leitura == 'L')
                {
                    printf("DIGITE O NUMERO DA LINHA: ");
                }
                else
                {
                    printf("DIGITE O NUMERO DA COLUNA: ");
                }
                fflush(stdin);
                scanf("%ld", &linha_coluna);
                if (linha_coluna > 0)
                {
                    flag3 = 0;
                }
                else
                {
                    printf("ENTRADA INVALIDA!\n");
                }
            }
            if (leitura == 'l' || leitura == 'L')
            {
                somar_linhas(head_lista, nome_matriz, linha_coluna);  //"linha_coluna" pode armazenar a coluna ou linha que o usuário deseja somar.
            }
            else
            {
                somar_colunas(head_lista, nome_matriz, linha_coluna);
            }
        }


        if (modo_escolhido == 5) //EXCLUIR MATRIZ
        {
            char nome_matriz[60];
            int flag = 0;
            while (!flag)
            {
                printf("DIGITE O NOME DA MATRIZ A SER EXCLUIDA: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz); //RETORNA 1 SE A MATRIZ ESTIVER CADASTRADA
                if (!flag)
                {
                    printf("MATRIZ NAO CADASTRADA!\n");
                }
                deletar_matriz(&head_lista, nome_matriz);
            }
        }


        if (modo_escolhido == 6) //LISTAR MATRIZES
        {
            listar_matrizes(head_lista);
        }

        if (modo_escolhido == 7) //PRINTA ELEMENTOS NAO NULOS
        {
            char nome_matriz[60];
            printf("DIGITE O NOME DA MATRIZ: ");
            fflush(stdin);
            fgets(nome_matriz, 59, stdin);
            remove_enter(nome_matriz);
            letras_maisculas(nome_matriz);
            printa_matriz(busca_matriz(head_lista, nome_matriz));
        }

        if (modo_escolhido == 8) //ZERA ELEMENTOS DE UMA MATRIZ
        {
            char nome_matriz[60];
            int flag = 0;
            while (!flag)
            {
                printf("DIGITE O NOME DA MATRIZ: ");
                fflush(stdin);
                fgets(nome_matriz, 59, stdin);
                remove_enter(nome_matriz);
                letras_maisculas(nome_matriz);
                flag = verificar_nome_repetido(head_lista, nome_matriz); //RETORNA 1 SE A MATRIZ ESTIVER CADASTRADA
                if (!flag)
                {
                    printf("MATRIZ NAO CADASTRADA!\n");
                }
            }
            apaga_todos_elementos(&head_lista,busca_matriz(head_lista, nome_matriz), nome_matriz);
            printf("ELEMENTOS APAGADOS COM SUCESSO!\n");
            system("PAUSE");
        }
    }

    return 0;
}
