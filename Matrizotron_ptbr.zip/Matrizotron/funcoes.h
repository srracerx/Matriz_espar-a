#ifndef FUNCOES_H
#define FUNCOES_H
#include "struct.h"

typedef aponta_matriz* MATRIZ; //Aponta para a matriz.
typedef aponta_matriz** P_MATRIZ; //Aponta para ponteiro de matriz.
typedef elemento_matriz* VALOR; //Aponta para o valor. 

void lista_matrizes(MATRIZ* primeira);   //Inicializa a lista de matrizes.
MATRIZ criar_matriz(char nome_matriz[60], int n_linhas, int n_colunas, MATRIZ* primeira); //Cria uma matriz. O ponteiro "primeiro" que antes apontava para NULL, agora apontará para essa matriz.
VALOR busca_matriz(MATRIZ primeira, char nome[]);  //DEVOLVE PONTEIRO PRA MATRIZ A PARTIR DE SEU NOME
void editar_elemento(VALOR primeiro, int i, int j, float valor);   //EDITA UM ELEMENTO JA EXISTENTE EM ALGUMA MATRIZ
void criar_elemento(MATRIZ primeira, char nome[], int i, int j, float valor);
void deletar_elemento(VALOR primeiro, int qual_linha, int qual_coluna); //RECEBE VALOR DO INICIO DA MATRIZ, BUSCA ELEMENTO E O APAGA (VIRA ZERO)
void apaga_todos_elementos(P_MATRIZ head, VALOR primeiro, char nome[60]); //RECEBE PRIMEIRO ELEMENTO, E APAGA TODOS
void deletar_matriz(P_MATRIZ primeira, char nome_matriz[60]);//Deletando uma matriz, deletamos todos os elementos dela. Fazemos isso com base no nome dela.
int verificar_nome_repetido(MATRIZ primeira, char nome_matriz[60]);
void listar_matrizes(MATRIZ primeira);
int consulta_elemento(VALOR primeiro, int i, int j);
void somar_linhas(MATRIZ primeira, char nome_da_matriz[60], int linha);
void somar_colunas(MATRIZ primeira, char nome_da_matriz[60], int coluna);
void remove_enter(char nome[]); //RETIRA \n DO FINAL DA STRING (CASO EXISTA)
void letras_maisculas(char nome[]); //CONVERTE STRING PARA LETRAS MAISCULAS
void printa_matriz(VALOR primeiro);

#endif
