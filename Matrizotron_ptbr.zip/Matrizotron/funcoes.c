#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <windows.h>
#include "struct.h"
#include "funcoes.h"

typedef aponta_matriz* MATRIZ; //Aponta para a matriz.
typedef aponta_matriz** P_MATRIZ; //Aponta para ponteiro de matriz.
typedef elemento_matriz* VALOR; //Aponta para o valor.

void lista_matrizes(MATRIZ* primeira)   //Inicializa a lista de matrizes.
{
    *primeira = NULL;
}

MATRIZ criar_matriz(char nome_matriz[60], int n_linhas, int n_colunas, MATRIZ* primeira)   //Cria uma matriz. O ponteiro "primeiro" que antes apontava para NULL, agora apontará para essa matriz.
{
    aponta_matriz* nova;  //Um ponteiro para estrutura

    nova = (aponta_matriz*)malloc(sizeof(aponta_matriz));  //O ponteiro anterior, agora aponta para espaço que pode comportar uma estrutura.

    nova->aponta_matriz = *primeira;  //O espaço, recentemente criado, agora aponta para a anterior primeira estrutura.

    *primeira = nova; //É bom fazer alterações aqui...
    strcpy((*primeira)->nome, nome_matriz);
    (*primeira)->m = n_linhas;
    (*primeira)->n = n_colunas;
    (*primeira)->head_matriz = NULL; //Pois, ao criar a matriz, ela não terá nenhum elemento.

    return *primeira;

}

VALOR busca_matriz(MATRIZ primeira, char nome[])  //DEVOLVE PONTEIRO PRA MATRIZ A PARTIR DE SEU NOME
{
    MATRIZ atual = primeira;
    while(atual != NULL)  //LOOP PARA BUSCAR QUAL MATRIZ
    {
        if(strcmp(atual->nome, nome) == 0)
        {
            return atual->head_matriz;
        }
        atual = atual->aponta_matriz;
    }
    return NULL;
}

void editar_elemento(VALOR primeiro, int i, int j, float valor)   //EDITA UM ELEMENTO JA EXISTENTE EM ALGUMA MATRIZ
{
    VALOR elemento_atual = primeiro;
	if(elemento_atual == NULL){
		return;
	}
    while(elemento_atual !=NULL)
    {
        if(elemento_atual->i == i && elemento_atual->j == j)
        {
            elemento_atual->valor = valor;
        }
        elemento_atual = elemento_atual->prox;
    }
}

void criar_elemento(MATRIZ primeira, char nome[], int i, int j, float valor)
{
    MATRIZ atual = primeira;
    VALOR matriz_buscada = NULL;
	if(atual != NULL){
		while(atual != NULL)  //LOOP PARA BUSCAR A MATRIZ
		{
			if(strcmp(atual->nome, nome) == 0)
			{
            matriz_buscada = atual->head_matriz;
				break;
			}
			atual = atual->aponta_matriz;
		}
	}
    if(atual == NULL)
    {
        return;
    }
    if(matriz_buscada == NULL) //SE NAO TEM ELEMENTOS NA MATRIZ
    {
        VALOR novo;
        novo = (VALOR) malloc(sizeof(VALOR));
        novo->i = i;
        novo->j = j;
        novo->valor = valor;
        novo->prox = NULL;
        atual->head_matriz = novo;
    }
    else   //SE JA TEM ALGUM ELEMENTO NA MATRIZ
    {
        VALOR novo;
        novo = (VALOR) malloc(sizeof(VALOR));
        novo->prox = matriz_buscada; //O ANTIGO PRIMEIRO Eh O PROXIMO DO NOVO
        atual->head_matriz = novo; //O NOVO AGR E O PRIMEIRO ELEMENTO DA LISTA
        novo->i = i;
        novo->j = j;
        novo->valor = valor;
    }
}

void deletar_elemento(VALOR primeiro, int qual_linha, int qual_coluna) //RECEBE VALOR DO INICIO DA MATRIZ, BUSCA ELEMENTO E O APAGA (VIRA ZERO)
{
    VALOR atual = primeiro;
    VALOR anterior = NULL;
    while(atual != NULL)
    {
        if(atual->i == qual_linha && atual->j == qual_coluna) //SE FOR O ELEMENTO PROCURADO
        {
            anterior->prox = atual->prox;
            free(atual);
        }
        anterior = atual;
        atual = atual->prox;
    }
}

void apaga_todos_elementos(P_MATRIZ head, VALOR primeiro, char nome[60]) //RECEBE PRIMEIRO ELEMENTO, E APAGA TODOS
{
    VALOR elemento_atual;
    VALOR apagar;
    VALOR proximo;
    MATRIZ matriz_atual;
    elemento_atual = primeiro;
    matriz_atual = *head;
    while(elemento_atual != NULL)
    {
        proximo = elemento_atual->prox;
        apagar = elemento_atual;
        free(apagar);
        if(proximo == NULL) //CASO NAO TENHAM MAIS, ACABE A FUNCAO
        {
            break;
        }
        elemento_atual = proximo;
    }
    while(matriz_atual != NULL)
      {
        if(strcmp(matriz_atual->nome, nome)== 0){
            matriz_atual->head_matriz = NULL;
            break;
        }
        matriz_atual = matriz_atual->aponta_matriz;
      }
}

void deletar_matriz(P_MATRIZ primeira, char nome_matriz[60])   //Deletando uma matriz, deletamos todos os elementos dela. Fazemos isso com base no nome dela.
{
    MATRIZ atual = *primeira;
    MATRIZ anterior = NULL;
    while(atual != NULL)
    {
        if(strcmp(atual->nome, nome_matriz) == 0)
        {
            char confirmacao;
            printf("DESEJA MESMO DELETAR %s ?\n", atual->nome);
            printf("DIGITE Y (OU DIGITE OUTRA LETRA PARA VOLTAR): ");
            fflush(stdin);
            scanf("%c", &confirmacao);
            if(confirmacao >= 'a' && confirmacao <= 'z')
            {
              confirmacao = (confirmacao - 'a') + 'A'; //CONVERTE PRA MAIUSCULA
            }
            if(confirmacao != 'Y')
            {
                return ; //SAI DA FUNCAO
            }
            //APAGA OS ELEMENTOS DA MATRIZ
            apaga_todos_elementos(primeira,atual->head_matriz, nome_matriz);

            //DELETANDO A MATRIZ (DA LISTA ENCADEADA)
            if(atual == *primeira){ //SE FOR A CABECA DA LISTA
              *primeira = atual->aponta_matriz; //O PROXIMO E A NOVA CABECA
              free(atual);
              printf("MATRIZ DELETADA!\n");
              system("PAUSE");
              return;
            }else{ //SE NAO FOR A CABECA DA LISTA
              anterior->aponta_matriz = atual->aponta_matriz; //LIGA O TERMO ANTERIOR AO PROXIMO
              free(atual);
              printf("MATRIZ DELETADA!\n");
              system("PAUSE");
              return;
            }
        }
        //PASSA PRO PROXIMO ALUNO DA LISTA
        anterior = atual;
        atual = atual->aponta_matriz;
    }
}

int verificar_nome_repetido(MATRIZ primeira, char nome_matriz[60])
{
    MATRIZ percorre;
    percorre = primeira;
    if(percorre != NULL)   //só entra se tiver mais alguma outra matriz para comparar os nomes.
    {
        while (strcmp(percorre->nome, nome_matriz) != 0)   //strcomp retorna 0 se for igual.
        {
            percorre = percorre->aponta_matriz;
            if(percorre == NULL)
            {
                return 0;
            }
        }

        if (strcmp(percorre->nome, nome_matriz) == 0)
        {
            return 1;
        }
    }
    return 0;
}

void listar_matrizes(MATRIZ primeira)
{
    if(primeira == NULL){
      printf("NAO EXISTEM MATRIZES CRIADAS!\n");
      system("PAUSE");
      return;
    }
    MATRIZ percorre;
    percorre = primeira;
    while (percorre != NULL)
    {
        printf(">>NOME: %s - %ldx%ld \n", percorre->nome, percorre->m, percorre->n);
        percorre = percorre->aponta_matriz;
    }
    system("PAUSE");
    return;
}

int consulta_elemento(VALOR primeiro, int i, int j)
{
    VALOR atual = primeiro;
    while(atual != NULL)
    {
        if(atual->i == i && atual->j == j)
        {
            return atual->valor;
        }
        atual = atual->prox;
    }
    return 0;
}

void somar_linhas(MATRIZ primeira, char nome_da_matriz[60], int linha)
{
    MATRIZ percorre_m; //Percorre a matriz
    VALOR percorre;  //Percorre os elementos da matriz
    float soma;
    percorre_m = primeira;  //Isso se refere à matriz.
    while (strcmp(percorre_m->nome, nome_da_matriz) != 0)    //Procurando a matriz pelo nome.
    {
        if(percorre_m == NULL)
        {
            printf("MATRIZ NAO ENCONTRADA!\n");
            system("PAUSE");
            return;
        }
        percorre_m = percorre_m->aponta_matriz;
    }
    soma = 0;  //À partir daqui, se refere aos elementos da matriz.
    percorre = percorre_m->head_matriz;
    while (percorre != NULL)
    {
        if (percorre->i == linha)
        {
            soma = percorre->valor + soma;
        }
        percorre = percorre->prox;
    }
    printf("\n>>A soma eh: %f\n\n", soma);
    system("PAUSE");
}

void somar_colunas(MATRIZ primeira, char nome_da_matriz[60], int coluna)
{
    MATRIZ percorre_m;
    VALOR percorre;
    float soma;
    soma = 0;
    percorre_m = primeira;

    while (strcmp(percorre_m->nome, nome_da_matriz) != 0)    //Procurando a matriz pelo nome.
    {
        percorre_m = percorre_m->aponta_matriz;
        if(percorre_m == NULL)
        {
            printf("MATRIZ NAO ENCONTRADA!\n");
            system("PAUSE");
            return;
        }
    }
    percorre = percorre_m->head_matriz;

    while (percorre != NULL)
    {
        if (percorre->j == coluna)
        {
            soma += percorre->valor;
        }
        percorre = percorre->prox;
    }

    printf("\n>>A soma eh: %f\n\n", soma);
    system("PAUSE");
}

void remove_enter(char nome[]) //RETIRA \n DO FINAL DA STRING (CASO EXISTA)
{
    int tamanho;
    int i;
    tamanho = strlen(nome);
    for (i = 0; i < tamanho; i++)
    {
        if (nome[i] == '\n')
        {
            nome[i] = '\0';
        }
    }
}

void letras_maisculas(char nome[]) //CONVERTE STRING PARA LETRAS MAISCULAS
{
    int tamanho;
    int i;
    tamanho = strlen(nome);
    for (i = 0; i < tamanho; i++)
    {
        if (nome[i] >= 'a' && nome[i] <= 'z')
        {
            nome[i] = ('A' + (nome[i] - 'a'));
        }
    }
}

void printa_matriz(VALOR primeiro)
{
    VALOR atual = primeiro;
    if(atual == NULL){
      printf("MATRIZ NAO POSSUE ELEMENTOS NAO NULOS!\n");
      system("PAUSE");
      return;
    }
    while(atual!=NULL)
    {
        printf("I: %ld J: %ld VALOR: %f\n", atual->i, atual->j, atual->valor);
        atual = atual->prox;
    }
    system("PAUSE");
}