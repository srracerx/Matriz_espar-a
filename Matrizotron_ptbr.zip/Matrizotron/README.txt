/////////MATRIZOTRON///////////
                              |
Trata-se de um programa capaz |
de criar matrizes esparsas e  |
realizar operações com elas.  |
O programa foi feito princi-  |
palmente colocando em prática |
o conceito de lista encadeada.|
                              |
///////////////////////////////


/////////FEITO POR://////////// 
                              |
                              |
André Bermudes Viana, p = 1   |
N° USP: 106 845 80            |
                              |
______________________________|
                              |
                              |
Lucas G. Mendes Miranda, p = 0|
N° USP: 102 658 92            |   
                              |
                              |
//////////////////////////////|               
